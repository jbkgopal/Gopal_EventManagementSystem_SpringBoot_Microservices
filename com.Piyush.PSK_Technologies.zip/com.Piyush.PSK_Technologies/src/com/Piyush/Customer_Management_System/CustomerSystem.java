package com.Piyush.Customer_Management_System;

public class CustomerSystem {
	private Customer customer;

	public void addCustomer(String name, String email, String phone) {
		customer = new Customer(name, email, phone);
		System.out.println("Customer added successfully.");
	}

	public void getCustomerDetails(String emailOrPhone) {
		if (customer.getEmail().equals(emailOrPhone) || customer.getPhone().equals(emailOrPhone)) {
			System.out.println("Customer details: ");
			System.out.println("Name: " + customer.getName());
			System.out.println("Email: " + customer.getEmail());
			System.out.println("Phone: " + customer.getPhone());
		}
		else {
			System.out.println();
		}
	}
}