package com.Piyush.piyush.Cake_Oredering_system;

// Task 1: Cake Ordering System

public class Cake {
	private String name;
	private double price;
	private static String description;

	public Cake(String name, double price, String description) {
		this.name = name;
		this.price = price;
		this.description = description;
	}

	public Cake(Object object) {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}

	public static String getDescription() {
		return description;
	}
}
