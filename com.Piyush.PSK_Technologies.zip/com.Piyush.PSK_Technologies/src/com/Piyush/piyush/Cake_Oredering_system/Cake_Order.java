package com.Piyush.piyush.Cake_Oredering_system;
// Task 1: Cake Ordering System



	public class Cake_Order {
		private Cake cake;
		private int quantity;
		private double totalPrice;

		public Cake_Order(Cake cake, int quantity) {
			this.cake = cake;
			this.quantity = quantity;
			this.totalPrice = calculateTotalPrice();
		}

		public double calculateTotalPrice() {
			return cake.getPrice() * quantity;
		}

		public void displayOrderDetails() {
			System.out.println("Cake Name: " + cake.getName());
			System.out.println("Quantity: " + quantity);
			System.out.println("Total Price: " + totalPrice);
			System.out.println("Description:-"+Cake.getDescription());
		}
	}
