package com.Piyush.Point_of_Sale__System;

import java.sql.Date;

public class Transaction {
	private Date date;
	private double amount;
	private String paymentType;

	public Transaction(Date date, double amount, String paymentType) {
		this.date = date;
		this.amount = amount;
		this.paymentType = paymentType;
	}

	public Date getDate() {
		return date;
	}

	public double getAmount() {
		return amount;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void processPayment(Payment payment) {
		this.amount = payment.getAmount();
	}

	public String generateReceipt() {
		return "Receipt for transaction on " + date + "\n" + "Amount: " + amount + "\n" + "Payment Type: "
				+ paymentType;
	}

}
