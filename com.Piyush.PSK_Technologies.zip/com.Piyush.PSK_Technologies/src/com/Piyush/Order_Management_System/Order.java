package com.Piyush.Order_Management_System;

import java.sql.Date;

public class Order {
	private String customer;
	private Date date;
	private String status;

	public Order(String customer, Date date, String status) {
		this.customer = customer;
		this.date = date;
		this.status = status;
	}

	public String getCustomer() {
		return customer;
	}

	public Date getDate() {
		return date;
	}

	public String getStatus() {
		return status;
	}

	public void updateStatus(String newStatus) {
		this.status = newStatus;
	}

	
		
	}

