package com.Piyush.COS_Main;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.Piyush.Customer_Management_System.CustomerSystem;
import com.Piyush.Inventory_Management_system.BakedGood;
import com.Piyush.Inventory_Management_system.Ingredient;
import com.Piyush.Order_Management_System.Order;
import com.Piyush.Point_of_Sale__System.Payment;
import com.Piyush.Point_of_Sale__System.Transaction;
import com.Piyush.Reporting_System.ReportingSystem;
import com.Piyush.Reporting_System.Transaction1;
import com.Piyush.piyush.Cake_Oredering_system.Cake;
import com.Piyush.piyush.Cake_Oredering_system.Cake_Order;

public class Manager {

	public static void main(String[] args) {
		// Task 1: Cake Ordering System
		System.out.println("__________😊😊WELCOME PIYUSH CAKE SHOPE😊😊😊 ___________");
		System.out.println("......🍰🍰Detail of cake 🍰🍰.....");

		Cake a = new Cake("Blackforest cake", 250.0, "Moist chocolate cake");
		Cake b = new Cake("whiteforest cake", 300.0, "Moist chocolate cake");
		Cake c = new Cake("Strawberry Shortcake", 500.0,
				"A sweet and tangy strawberry cake layered with whipped cream and fresh ");
		Cake d = new Cake("Carrot Cake", 600.0,
				"A moist and flavorful carrot cake filled with chopped nuts and spices, topped with a creamy cream cheese frosting");
		Cake e = new Cake("emon Lavender Pound Cake", 900.0, "A refreshing lemon pound cake ");
		Cake_Order A = new Cake_Order(a, 2);
		A.displayOrderDetails();
		System.out.println("_____________________________________");

		Cake_Order B = new Cake_Order(a, 2);
		B.displayOrderDetails();
		System.out.println("_____________________________________");

		Cake_Order C = new Cake_Order(b, 1);
		C.displayOrderDetails();
		System.out.println("_____________________________________");

		Cake_Order D = new Cake_Order(a, 2);
		D.displayOrderDetails();
		System.out.println("_____________________________________");

		Cake_Order E = new Cake_Order(a, 2);
		E.displayOrderDetails();
		System.out.println("_____________________________________");

		// Task 2: Inventory Management System

		System.out.println("====Details of Ingedient Add====");

		Ingredient sugar = new Ingredient("sugar", 50, 3.5);
		Ingredient cocoaPowder = new Ingredient("cocoa Powder", 100, 3.5);
		Ingredient Butter = new Ingredient("Butter", 50, 1.5);
		Ingredient eggs = new Ingredient("Eggs", 20, 3.0);

		List<Ingredient> ingredients = new ArrayList<>();

		ingredients.add(Butter);
		ingredients.add(sugar);
		ingredients.add(eggs);

		BakedGood bakedGood = new BakedGood("Blackforest cake", 30.0, ingredients);
		System.out.println("Name:- " + bakedGood.getName());

		System.out.println("Total Cost of Ingedients:" + bakedGood.calculateTotalCost());
		bakedGood.updateInventoryLevels();

		// Task3. Point of sale system
		System.out.println("_________________********____________________");

		System.out.println("__💰💰Payment Recipt details💰💰__");

		Transaction transaction = new Transaction(new Date(2024, 07, 10), 100.0, "Credit Card");
		Payment payment = new Payment("Cash", 250.0);
		System.out.println("__________________*****___________________");

		Transaction transaction1 = new Transaction(new Date(2024, 07, 20), 100.0, "online");
		Payment payment1 = new Payment("online", 300.0);

		Transaction transaction2 = new Transaction(new Date(2024, 07, 21), 100.0, "Googlepay");
		Payment payment2 = new Payment("online", 500.0);

		Transaction transaction3 = new Transaction(new Date(2024, 07, 22), 100.0, "cash");
		Payment payment3 = new Payment("online", 600.0);

		Transaction transaction4 = new Transaction(new Date(2024, 07, 23), 100.0, "paytm");
		Payment payment4 = new Payment("online", 9000.0);

		Transaction transaction5 = new Transaction(new Date(2024, 07, 24), 100.0, "Googlepay");
		Payment payment5 = new Payment("online", 1000.0);

		transaction.processPayment(payment);
		System.out.println(transaction.generateReceipt());
		System.out.println("_____________________________________");
		System.out.println(transaction1.generateReceipt());
		System.out.println("_____________________________________");
		System.out.println(transaction2.generateReceipt());
		System.out.println("_____________________________________");
		System.out.println(transaction3.generateReceipt());
		System.out.println("_____________________________________");
		System.out.println(transaction4.generateReceipt());
		System.out.println("_____________________________________");
		System.out.println(transaction5.generateReceipt());
		System.out.println("________________********______________");

		// Task 4 customer management system
		System.out.println("_____________________________________");

		System.out.println("===👤👤Customer Details👤👤===");
		System.out.println("_____________________________________");

		CustomerSystem customerSystem = new CustomerSystem();
		System.out.println("_____________________________________");

		customerSystem.addCustomer("Piyush Wadhai", "piyushwadhai146@.com", "9021744384");
		customerSystem.getCustomerDetails("piyushwadhai146@.com");
		System.out.println("_____________________________________");

		customerSystem.addCustomer("Nandini Wadhai", "NandiniWadhai@.com", "9021744384");
		customerSystem.getCustomerDetails("NandiniWadhai@.com");
		System.out.println("_____________________________________");
		System.out.println("_____________________________________");

		customerSystem.addCustomer("Akash Wadhai", "Akashwadhai146@.com", "9021744384");
		customerSystem.getCustomerDetails("Akashwadhai146@.com");
		System.out.println("_____________________________________");

		customerSystem.addCustomer(" Ankush Wadhai", "Ankushwadhai146@.com", "9021744384");
		customerSystem.getCustomerDetails("Ankushwadhai146@.com");
		System.out.println("_____________________________________");

		// Task 5 order management system
		System.out.println("_____________________________________");

		// Create a new order
		System.out.println("===New order Details===");
		System.out.println("_____________________________________");

		Order order = new Order("Piyush Wadhai", new Date(2024, 07, 17), "pending");
		System.out.println("Order created: " + order.getCustomer() + ", " + order.getDate() + ", " + order.getStatus());
		System.out.println("_____________________________________");

		Order order1 = new Order("Nandini Wadhai", new Date(2024, 07, 15), "pending");
		System.out.println("Order created: " + order.getCustomer() + ", " + order.getDate() + ", " + order.getStatus());
		System.out.println("_____________________________________");

		Order order2 = new Order("Ankush Wadhai", new Date(2024, 07, 16), "pending");
		System.out.println("Order created: " + order.getCustomer() + ", " + order.getDate() + ", " + order.getStatus());
		System.out.println("_____________________________________");

		Order order3 = new Order("Akash wadhai", new Date(2024, 07, 20), "pending");
		System.out.println("Order created: " + order.getCustomer() + ", " + order.getDate() + ", " + order.getStatus());
		System.out.println("_____________________________________");

		System.out.println("========= ORDER  STATUS =======");
		// Update the status of the order
		order.updateStatus("delivered");
		System.out.println("Order updated: " + order.getCustomer() + ", " + order.getDate() + ", " + order.getStatus());
		System.out.println("_____________________________________");

		order1.updateStatus("delivered");
		System.out.println("Order updated: " + order.getCustomer() + ", " + order.getDate() + ", " + order.getStatus());
		System.out.println("_____________________________________");

		order2.updateStatus("delivered");
		System.out.println("Order updated: " + order.getCustomer() + ", " + order.getDate() + ", " + order.getStatus());
		System.out.println("_____________________________________");

		order3.updateStatus("delivered");
		System.out.println("Order updated: " + order.getCustomer() + ", " + order.getDate() + ", " + order.getStatus());
		System.out.println("_____________________________________");

		order.updateStatus("delivered");
		System.out.println("Order updated: " + order.getCustomer() + ", " + order.getDate() + ", " + order.getStatus());
		System.out.println("_____________________________________");

		// Task 6 Report system
		System.out.println("=======//ALL TOTAL REPORT//=======");

		List<Transaction1> transactions = new ArrayList<>();
		transactions.add(new Transaction1(200.0));
		transactions.add(new Transaction1(300.0));
		transactions.add(new Transaction1(400.0));
		transactions.add(new Transaction1(355.0));
		transactions.add(new Transaction1(34.0));
		transactions.add(new Transaction1(3054.0));
		transactions.add(new Transaction1(34.0));
		transactions.add(new Transaction1(355.0));
		transactions.add(new Transaction1(600.0));
		transactions.add(new Transaction1(665.0));
		transactions.add(new Transaction1(300.0));
		transactions.add(new Transaction1(354.0));
		transactions.add(new Transaction1(32.0));
		transactions.add(new Transaction1(359.0));
		transactions.add(new Transaction1(30.0));
		transactions.add(new Transaction1(900.0));
		transactions.add(new Transaction1(100.0));

		List<BakedGood1> ll = null;

		ReportingSystem reportingSystem = new ReportingSystem(transactions, ll);
		reportingSystem.generateDailySalesReport();
		System.out.println("_____________________________________");
		reportingSystem.generateTopSellingBakedGoodsReport();
		System.out.println("_____________________________________");

	}

}
