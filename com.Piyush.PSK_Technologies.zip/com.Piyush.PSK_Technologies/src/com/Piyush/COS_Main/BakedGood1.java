package com.Piyush.COS_Main;

public class BakedGood1 {
	private String name;
	private int quantitySold;

	public BakedGood1(String name, int quantitySold) {
		this.name = name;
		this.quantitySold = quantitySold;
	}

	public String getName() {
		return name;
	}

	public int getQuantitySold() {
		return quantitySold;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setQuantitySold(int quantitySold) {
		this.quantitySold = quantitySold;
	}

	@Override
	public String toString() {
		return "BakedGood1 [name=" + name + ", quantitySold=" + quantitySold + "]";
	}

}
