package com.Piyush.Reporting_System;

public class Transaction1 {
	private double amount;

	public Transaction1(double amount) {
		this.amount = amount;
	}

	public double getAmount() {
		return amount;
	}

}
