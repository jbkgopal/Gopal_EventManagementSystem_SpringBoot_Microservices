package com.Piyush.Reporting_System;

import java.util.ArrayList;
import java.util.List;

import com.Piyush.COS_Main.BakedGood1;

public class ReportingSystem {
	private List<Transaction1> transactions;

	private List<BakedGood1> bakedGoods1;


	public ReportingSystem(List<Transaction1> transactions, List<BakedGood1> bakedGoods1) {
		this.transactions = transactions;
		this.bakedGoods1 = bakedGoods1;
	}

	public void generateDailySalesReport() {
		double totalAmount = 0;
		int numTransactions = 0;
		for (Transaction1 transaction : transactions) {
			totalAmount += transaction.getAmount();
			numTransactions++;
		}
		System.out.println("Total Amount Sold: " + totalAmount);
		System.out.println("Number of Transactions: " + numTransactions);
	}

	public void generateTopSellingBakedGoodsReport() {
		List<BakedGood1> topSellingBakedGoods = new ArrayList<BakedGood1>();
	
		topSellingBakedGoods.add(new BakedGood1("butter", 5));
		topSellingBakedGoods.add(new BakedGood1("Bread", 10));
		topSellingBakedGoods.add(new BakedGood1("cookie", 19));
		topSellingBakedGoods.add(new BakedGood1("Pastries", 16));
		topSellingBakedGoods.add(new BakedGood1("Muffins", 15));
		topSellingBakedGoods.add(new BakedGood1("Pies", 22));
		topSellingBakedGoods.add(new BakedGood1("Apple tart bakery", 11));
		topSellingBakedGoods.add(new BakedGood1("Artisanal crusts", 12));

		for (BakedGood1 bakedGood : topSellingBakedGoods) {
			System.out.println("Top Selling Baked Goods: "+bakedGood.getName() + ": " + bakedGood.getQuantitySold());
		}
	}

	@Override
	public String toString() {
		return "ReportingSystem [transactions=" + transactions + ", bakedGoods1=" + bakedGoods1 + "]";
	}

}
