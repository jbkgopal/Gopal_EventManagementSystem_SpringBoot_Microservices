package com.Piyush.Inventory_Management_system;
//Task 2: Inventory Management System

import java.util.List;

public class BakedGood {
	private String name;
	private double price;
	private List<Ingredient> ingredients;

	public BakedGood(String name, double price, List<Ingredient> ingredients) {
		this.name = name;
		this.price = price;
		this.ingredients = ingredients;
	}

	public double calculateTotalCost() {
		double totalCost = 0;
		for (Ingredient ingredient : ingredients) {
			totalCost += ingredient.getQuantity() * ingredient.getUnitPrice();
		}
		return totalCost;
	}

	public void updateInventoryLevels() {
		for (Ingredient ingredient : ingredients) {
			ingredient.setQuantity(ingredient.getQuantity() - 1);
		}
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @return the ingredients
	 */
	public List<Ingredient> getIngredients() {
		return ingredients;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 * @param ingredients the ingredients to set
	 */
	public void setIngredients(List<Ingredient> ingredients) {
		this.ingredients = ingredients;
	}

}
