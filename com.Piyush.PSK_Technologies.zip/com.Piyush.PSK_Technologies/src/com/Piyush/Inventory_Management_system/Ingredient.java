package com.Piyush.Inventory_Management_system;

public class Ingredient {
	private String name;
	private int quantity;
	private double unitPrice;

	public Ingredient(String name, int quantity, double unitPrice) {
		this.name = name;
		this.quantity = quantity;
		this.unitPrice = unitPrice;
	}

	public String getName() {
		return name;
	}

	public int getQuantity() {
		return quantity;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	

	

	
}
