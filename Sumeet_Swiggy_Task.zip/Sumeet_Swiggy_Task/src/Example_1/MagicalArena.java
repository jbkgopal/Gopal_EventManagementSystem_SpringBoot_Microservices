package Example_1;
import java.util.Random;

public class MagicalArena {
    private Player playerA;
    private Player playerB;
    private Random random;

    public MagicalArena(Player playerA, Player playerB) {
        this.playerA = playerA;
        this.playerB = playerB;
        this.random = new Random();
    }

    public void startMatch() {
        System.out.println("Welcome to the Magical Arena!");
        System.out.println("Player A: " + playerA);
        System.out.println("Player B: " + playerB);

        Player attacker = playerA.getHealth() < playerB.getHealth() ? playerA : playerB;
        Player defender = attacker == playerA ? playerB : playerA;

        while (playerA.getHealth() > 0 && playerB.getHealth() > 0) {
            System.out.println("\n" + attacker.getName() + " attacks!");
            int attackRoll = rollDie();
            int defenseRoll = rollDie();
            int attackDamage = attacker.getAttack() * attackRoll;
            int defenseStrength = defender.getStrength() * defenseRoll;
            int damageDealt = Math.max(0, attackDamage - defenseStrength);

            System.out.println("Attack roll: " + attackRoll + ", Defense roll: " + defenseRoll);
            System.out.println("Attack damage: " + attackDamage + ", Defense strength: " + defenseStrength);
            System.out.println("Damage dealt: " + damageDealt);

            defender.setHealth(defender.getHealth() - damageDealt);

            System.out.println(defender.getName() + " health: " + defender.getHealth());

            // Switch roles
            Player temp = attacker;
            attacker = defender;
            defender = temp;
        }

        System.out.println("\nMatch over!");
        if (playerA.getHealth() > 0) {
            System.out.println("Player A wins!");
        } else {
            System.out.println("Player B wins!");
        }
    }

    private int rollDie() {
        return random.nextInt(6) + 1;
    }

    public static class Player {
        private String name;
        private int health;
        private int strength;
        private int attack;

        public Player(String name, int health, int strength, int attack) {
            this.name = name;
            this.health = health;
            this.strength = strength;
            this.attack = attack;
        }

        public String getName() {
            return name;
        }

        public int getHealth() {
            return health;
        }

        public void setHealth(int health) {
            this.health = health;
        }

        public int getStrength() {
            return strength;
        }

        public int getAttack() {
            return attack;
        }

        @Override
        public String toString() {
            return "Player " + name + " - Health: " + health + ", Strength: " + strength + ", Attack: " + attack;
        }
    }

    public static void main(String[] args) {
        Player playerA = new Player("A", 50, 5, 10);
        Player playerB = new Player("B", 100, 10, 5);

        MagicalArena arena = new MagicalArena(playerA, playerB);
        arena.startMatch();
    }
}