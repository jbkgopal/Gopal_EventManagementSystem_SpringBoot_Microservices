package Example_2;
public class MagicalArena {
    public static void main(String[] args) {
        Player playerA = new Player("Player A", 50, 5, 10);
        Player playerB = new Player("Player B", 100, 10, 5);

        simulateMatch(playerA, playerB);
    }

    public static void simulateMatch(Player player1, Player player2) {
        int turn = 0;
        while (player1.isAlive() && player2.isAlive()) {
            Player attacker, defender;
            if (player1.getHealth() <= player2.getHealth()) {
                attacker = player1;
                defender = player2;
            } else {
                attacker = player2;
                defender = player1;
            }

            attacker.attackPlayer(defender);
            turn++;
        }

        Player winner = player1.isAlive() ? player1 : player2;
        System.out.println(winner.getName() + " wins the match after " + turn + " turns!");
    }
}
