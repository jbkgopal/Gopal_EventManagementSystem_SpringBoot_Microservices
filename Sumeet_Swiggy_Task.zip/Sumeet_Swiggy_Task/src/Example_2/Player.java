package Example_2;
import java.util.Random;

public class Player {
    private String name;
    private int health;
    private int strength;
    private int attack;
    private Random random;

    public Player(String name, int health, int strength, int attack) {
        this.name = name;
        this.health = health;
        this.strength = strength;
        this.attack = attack;
        this.random = new Random();
    }

    public boolean isAlive() {
        return health > 0;
    }

    public int rollDie() {
        return random.nextInt(6) + 1;
    }

    public void attackPlayer(Player defender) {
        int attackRoll = rollDie();
        int defenseRoll = defender.rollDie();

        int attackDamage = attack * attackRoll;
        int defenseValue = defender.strength * defenseRoll;

        int damage = Math.max(attackDamage - defenseValue, 0);

        defender.health -= damage;

        System.out.println(name + " attacks " + defender.name + "!");
        System.out.println(name + " rolls a " + attackRoll + " (Attack Damage: " + attackDamage + ")");
        System.out.println(defender.name + " rolls a " + defenseRoll + " (Defense Value: " + defenseValue + ")");
        System.out.println(defender.name + " takes " + damage + " damage and is now at " + defender.health + " health.");
        System.out.println("----------------------------------------");
    }

    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }
}
