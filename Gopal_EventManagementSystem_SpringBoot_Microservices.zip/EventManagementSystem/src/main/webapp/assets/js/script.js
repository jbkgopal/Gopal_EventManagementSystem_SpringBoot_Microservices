function deleteBooking(){
    return confirm('Are You Sure You Want To delete the booking');
}
function deleteUser(){
    return confirm('Are You Sure You Want to delete this User');
}
function deleteVendor(){
    return confirm('Are You Sure You Want to delete this Vendor');
}
function deleteHotel(){
    return confirm('Are You Sure You Want to delete this Hotel');
    
}
function deleteCatering(){
    return confirm('Are You Sure You Want to delete this Catering');
}
function deleteEvent(){
    return confirm('Are You Sure You Want to delete this Event');
}
function cancelBooking(){
    return confirm('Are You Sure You Want Cancel the booking');
}